import {   ref , set , child, get , update , remove  } from "https://www.gstatic.com/firebasejs/9.4.1/firebase-database.js" ;
import { database } from "./lib/firebaselib.js";

const formE = document.getElementById("form-C");
const btnSave = document.getElementById("btn-save");
const btnUpdate = document.getElementById("btn-update");
const btnSelect = document.getElementById("btn-select");
const btnDelete = document.getElementById("btn-delete");

formE.addEventListener('submit', async(e)=>{
    e.preventDefault();
    const ImageE = formE['image-file'].value;
    const NammeE = formE['name'].value;
    const PriceE = formE['price'].value;
    console.log(ImageE,NammeE, PriceE)
    function InsertData(){
        set(ref(database,"products/"+NammeE),{
            image:ImageE,
            name:NammeE,
            price:PriceE
        })
        .then(()=>{
            alert("datos almacenados con éxito");
        })
        .catch((error)=>{
            alert("datos no almacenados"+error);
        });
    }
    function SelectData(){
        const dbref= ref(database);        
        get(child(dbref,"products/"+NammeE)).then((snapshot)=>{
            if(snapshot.exist()){
            ImageE = snapshot.val().image;
            PriceE = snapshot.val().price;
            }
            else{
                alert("Datos no encontrados");
            }
        })
        .catch((error)=>{
            alert("datos no almacenados, error"+error);
        });

    }
    function UpdateData(){
        update(ref(database,"products/"+NammeE),{
            image:ImageE,
            price:PriceE
        })
        .then(()=>{
            alert("datos actualizados con éxito");
        })
        .catch((error)=>{
            alert("datos no actualizados"+error);
        });
    }
    function DeleteData(){
        remove(ref(database,"products/"+NammeE))
        .then(()=>{
            alert("datos actualizados con éxito");
        })
        .catch((error)=>{
            alert("datos no actualizados"+error);
        });
    }
    btnSave.addEventListener('click',InsertData);
    btnSelect.addEventListener('click',SelectData);
    btnUpdate.addEventListener('click',UpdateData);
    btnDelete.addEventListener('click',DeleteData);

})

/*formE.addEventListener(id="btn-save", async(e)=>{
    e.preventDefault();
    const ImageE = formE['image-file'].value;
    const NammeE = formE['name'].value;
    const PriceE = formE['price'].value;
    console.log(ImageE,NammeE, PriceE)
    function InsertData(){
        set(ref(database,"products/"+NammeE),{
            image:ImageE,
            name:NammeE,
            price:PriceE
        })
        .then(()=>{
            alert("datos almacenados con éxito");
        })
        .catch((error)=>{
            alert("datos no almacenados"+error);
        });
    }
    function SelectData(){
        const dbref= ref(database);
         
        get(child(dbref,"products/"+NammeE)).then((snapshot)=>{
            if(snapshot.exist()){
            ImageE = snapshot.val().image;
            NammeE = snapshot.val().name;
            PriceE = snapshot.val().price;
            }
            else{
                alert("Datos no encontrados");
            }
        })
        .catch((error)=>{
            alert("datos no almacenados, error"+error);
        });

    }*/

    