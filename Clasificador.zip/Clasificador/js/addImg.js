import { database , app} from "./lib/firebaselib.js";
import {getStorage , ref as sRef , uploadBytesResumable, getDownloadURL} from "https://www.gstatic.com/firebasejs/9.4.1/firebase-storage.js";
var files = [];
var reader = new FileReader();

var namebox = document.getElementById('namebox');
var extlab= document.getElementById('extlab');
var myimg = document.getElementById('myimg');
var proglab = document.getElementById('upprogress');
var SelBtn = document.getElementById('selbtn');
var UpBtn = document.getElementById('upbtn');
var DownBtn = document.getElementById('downbtn');
var zxc11 = document.getElementById('zxc1');

var input = document.createElement('input');
input.type = 'file';

input.onchange = e =>{
    files = e.target.files;

    var extention = GetFileExt(files[0]);
    var name = GetFileName(files[0]);
    
    namebox.value = name;
    extlab.innerHTML = extention;

    reader.readAsDataURL(files[0]);

}
reader.onload = function(){
    myimg.src = reader.result;
}

//seccion
SelBtn.onclick = function(){
    input.click();
}
function GetFileExt(file){
    var temp = file.name.split('_');
    var ext = temp.slice((temp.length-1),(temp.length));
    return '.'+ ext[0];
}
function GetFileName(file){
    var temp = file.name.split('_');
    var fname = temp.slice(0,-1).join('.');
    return fname;
}
//subida

async function UploadProcess(){
    var ImgToUpload =files[0];
    var ImgName =  namebox.value + extlab.innerHTML;
    const metaData ={
        contentType:ImgToUpload.type
    }
    const storage = getStorage();
    const stroageRef = sRef(storage,"Images/"+ImgName);
    const UploadTask = uploadBytesResumable(stroageRef,ImgToUpload,metaData);
    UploadTask.on('state-changed',(snapshot)=>{
        var progess = (snapshot.bytesTransferred / snapshot.totalBytes)*100;
        proglab.innerHTML = "  Cargando"+progess+"%";
        
    },
    (error) =>{
        alert("error: image not uploaded!");
    },
    ()=>{
        getDownloadURL(UploadTask.snapshot.ref).then((downloadURL)=>{
            console.log(downloadURL); 

            var modelo = null;
        //funcion asincronica
        (async() => {
            console.log("Cargando modelo...");
            modelo = await tf.loadLayersModel("model.json");
            console.log("Modelo cargado");
            predecir_foto()
        })();
        
        
        var micanvas = document.getElementById("micanvas");
        var ctx = micanvas.getContext("2d");
        console.log(downloadURL); 
        var miimagen= new Image();
        miimagen.src = reader.result;

        //dibujando la imagen en un canvas
        miimagen.onload = function(){
            ctx.drawImage(miimagen,0,0,224,224);
                console.log("imagen cargada");
            }  
        
    
        
        function predecir_foto(){
            if (modelo != null){
                 // ciclo for para separar los colores rgb en tres vectores
                 var ctx2 = micanvas.getContext("2d");

                 var imgData = ctx2.getImageData(0,0, micanvas.width, micanvas.height);//extraemos los pixeles
                 // ciclo for para separar los colores rgb en tres vectores
                 
 
                 var rojo=[];
                 var verde=[];
                 var azul=[];
                 var i=0;
                 for (var p=0; p < imgData.data.length; p+= 4) {
                     rojo[i] = imgData.data[p];
                     verde[i] = imgData.data[p+1];
                     azul[i] = imgData.data[p+2];
                     i+=1;
                 }
                 console.log(rojo);
                 var array_concatenado=[];
                 array_concatenado = rojo.concat(verde,azul);//concatenamos los arrays de cada color en uno solo
                 
                 var tensor = tf.tensor4d(array_concatenado,[1, 224, 224, 3]);//damos forma al array para que acepte el modelo
                 //console.log("imprimiendo tensor: "+tensor);
                 
                 var resultado = modelo.predict(tensor).dataSync();//predecimos
 
                 var respuesta;
                 var respuesta2;
                 respuesta="Benigno "+(resultado[0]*100).toFixed(3)+"%";
                 respuesta2="Maligno "+(resultado[1]*100).toFixed(3)+"%";
                 console.log(respuesta);
                 console.log(respuesta2);
                if(resultado[0]>=resultado[1]){
                    console.log("el cancer es benigno");
                    zxc11.innerHTML = "el cancer es benigno";
                }
                if(resultado[0]<=resultado[1]){
                    console.log("el cancer es maligno");
                    zxc11.innerHTML = "el cancer es maligno";
                }
            }
        }
        
        });
    }
    );

    
}

UpBtn.onclick = UploadProcess; 






/*
var modelo = null;
        //funcion asincronica
        (async() => {
            console.log("Cargando modelo...");
            modelo = await tf.loadLayersModel("model.json");
            console.log("Modelo cargado");
            predecir_foto()
        })();
        
        
        var micanvas = document.getElementById("micanvas");
        var ctx = micanvas.getContext("2d");
    
        var miimagen= new Image();
        miimagen.src = "maligno.jpg";

        //dibujando la imagen en un canvas
        miimagen.onload = function(){
            ctx.drawImage(miimagen,0,0,224,224);
            
        }
        
        var rojo=[];
        var verde=[];
        var azul=[];
        var i=0;
        var imgData = ctx.getImageData(0,0, 224, 224);//son coordenadas del cambas pequeño para obtener su tamaño
        // ciclo for para separar los colores rgb en tres vectores
        for (var p=0; p < imgData.data.length; p+= 4) {
            rojo[i] = imgData.data[p] / 255;
            verde[i] = imgData.data[p+1] / 255;
            azul[i] = imgData.data[p+2] / 255;
            i+=1;
        }

        var array_concatenado=[];
        array_concatenado = rojo.concat(verde,azul);//concatenamos los arrays de cada color en uno solo
        var tensor = tf.tensor4d(array_concatenado,[1, 224, 224, 3]);//damos forma al array para que acepte el modelo
            
        
        function predecir_foto(){
            if (modelo != null){
                var resultado = modelo.predict(tensor).dataSync();//predecimos
                if(resultado[0]>=resultado[1]){
                    console.log("el cancer es benigno");
                }
                else{
                    console.log("el cancer es maligno");
                }
            }
        }
        
*/