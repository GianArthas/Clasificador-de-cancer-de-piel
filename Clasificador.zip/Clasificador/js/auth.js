import AuthService from "./lib/services/authService.js";

const authService = new AuthService();

const loginForm = document.getElementById("login-form");
loginForm.addEventListener('submit', loginFormSubmit);

const register = document.getElementById("register-form")
register.addEventListener('submit', registerFormSubmit);

function loginFormSubmit(event){
    event.preventDefault();
    const emailInput = document.getElementById("login-email");
    const passwordInput = document.getElementById("login-password");

    authService.login(emailInput.value, passwordInput.value)
        .then((logged) => {
            /* detalles asdjasd
            adjasldkajsld
            askldjasldl
            No olvidar*/
            /*location.href ="/secret.html";*/
        })
        .catch(error => console-log(error));
}

function registerFormSubmit(event){
    event.preventDefault();
    const emailInput = document.getElementById("register-email");
    const passwordInput = document.getElementById("register-password");

    authService.register(emailInput.value, passwordInput.value)
        .then((logged) =>{
            location.href ="/secret.html";
        })
        .catch(error => console-log(error));
}