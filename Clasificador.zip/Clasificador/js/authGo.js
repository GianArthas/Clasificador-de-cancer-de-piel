import { login , logout } from "./lib/services/authGService.js";
import { auth } from "./lib/firebaselib.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.4.1/firebase-auth.js"
const buttonLogin = document.querySelector("#button-login");
const buttonLogout = document.querySelector("#button-logout");
const modeloP= document.querySelector("#modelo");
const userInfo= document.querySelector("#user-info");
const evalurar= document.querySelector("#eval");

let currentUser;
let ema;
onAuthStateChanged(auth, (user) => {
    if (user) {
      // User is signed in, see docs for a list of available properties
      // https://firebase.google.com/docs/reference/js/firebase.User
      currentUser=user;
      console.log("usuario logeado",currentUser.displayName);
      init();
      ema= currentUser.email;
      console.log(ema);
    } else {
      console.log("no hay usuario logeado");
    }
  });

buttonLogin.addEventListener("click", async (e) =>{
    try {
        currentUser = await login();
    } catch (error) {
        
    }
})

buttonLogout.addEventListener("click", async (e) =>{
    logout();
    buttonLogin.classList.remove("hidden");
    buttonLogout.classList.add("hidden");
    modeloP.classList.add("hidden");
    evalurar.classList.add("hidden");

})

function init() {
    buttonLogin.classList.add("hidden");
    buttonLogout.classList.remove("hidden");
    modeloP.classList.remove("hidden");
    evalurar.classList.remove("hidden");

    userInfo.innerHTML= `
    <img id="z1" src="${currentUser.photoURL}" />
    <span id="z2">${currentUser.displayName}</span>
    `;
}


