import ProductService from "./lib/services/productService.js";

let productService = new ProductService();

getProducts();

function getProducts(){
    productService.getProducts()
        .then((products) =>{
            showProducts(products);
        })
        .catch(error => console.log(error));
}

function showProducts(products){
    const productTableElement = document.getElementById("products-table");
    productTableElement.innerHTML = "";
    let productsArray = Object.keys(products).map((key) => products[key]);
    productsArray.forEach(producto => {
        productTableElement.innerHTML+= `<tr>
            <th scope="row"><img src="${producto.image}" alt="" class="product-img"></th>
            <td>${producto.name}</td>
            <td>$${producto.price}</td>    
        </tr>
        
        `;

    });
}